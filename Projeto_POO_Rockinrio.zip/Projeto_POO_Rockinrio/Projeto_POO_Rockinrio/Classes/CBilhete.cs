﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projeto_POO_Rockinrio.Classes
{
    abstract class  CBilhete
    {
        private string oid;
        private DateTime data_criacao;
        private float preco;
        private string numero;
         

        public string Oid { get => oid; set => oid = value; }
        public DateTime Data_criacao { get => data_criacao; set => data_criacao = value; }
        public float Preco { get => preco; set => preco = value; }
        public string Numero { get => numero; set => numero = value; }

        public abstract CBilhete Criar ();
        
        public abstract CBilhete Alterar ();
        
        public abstract CBilhete Apagar ();
         
    }

    
}
