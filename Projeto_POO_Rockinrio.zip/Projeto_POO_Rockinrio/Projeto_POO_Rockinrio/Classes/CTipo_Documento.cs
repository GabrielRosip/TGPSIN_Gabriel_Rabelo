﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projeto_POO_Rockinrio.Classes
{
    class CTipo_Documento
    {
        private string oidTipoDocumento;
        private string deescricao;

        public string OidTipoDocumento { get => oidTipoDocumento; set => oidTipoDocumento = value; }
        public string Deescricao { get => deescricao; set => deescricao = value; }
    }
}
