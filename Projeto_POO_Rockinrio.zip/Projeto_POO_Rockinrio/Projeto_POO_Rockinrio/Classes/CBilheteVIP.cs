﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projeto_POO_Rockinrio.Classes
{
    class CBilheteVIP : CBilhete
    {
        private string oidVIP;
        private string lugar;
        

        public string Lugar { get => lugar; set => lugar = value; }
        public string OidVIP { get => oidVIP; set => oidVIP = value; }

        public override CBilhete Criar()
        {
            return this;
        }
        public override CBilhete Alterar()
        {
            return this;
        }
        public override CBilhete Apagar()
        {
            return this;
        }
    }
}
