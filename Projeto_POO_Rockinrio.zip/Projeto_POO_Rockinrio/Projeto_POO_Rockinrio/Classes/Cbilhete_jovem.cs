﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projeto_POO_Rockinrio.Classes
{
    class Cbilhete_jovem:CBilhete
    {
        private string oidjovem;
        private string cartaojovem;

        public string Cartaojovem { get => cartaojovem; set => cartaojovem = value; }
        public string Oidjovem { get => oidjovem; set => oidjovem = value; }

        public override CBilhete Criar()
        {
            return this;
        }
        public override CBilhete Alterar()
        {
            return this;
        }
        public override CBilhete Apagar()
        {
            return this;
        }
    }
}
