﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projeto_POO_Rockinrio.Classes
{
    class CUtilizador
    {
        private string oidUtilizador;
        private string Username;
        private string Password;
        private string nome;

        public string OidUtilizador { get => oidUtilizador; set => oidUtilizador = value; }
        public string Username1 { get => Username; set => Username = value; }
        public string Password1 { get => Password; set => Password = value; }
        public string Nome { get => nome; set => nome = value; }
    }
}
