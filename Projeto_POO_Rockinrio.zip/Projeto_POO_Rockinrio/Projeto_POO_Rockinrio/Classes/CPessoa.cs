﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projeto_POO_Rockinrio.Classes
{
    class CPessoa
    {
        private string oidPessoa;
        private string nome;
        private string morada;
        private string email;
        private string telefone;
        private string docPessoal;
        private string docFiscal;

        public string OidPessoa { get => oidPessoa; set => oidPessoa = value; }
        public string Nome { get => nome; set => nome = value; }
        public string Morada { get => morada; set => morada = value; }
        public string Email { get => email; set => email = value; }
        public string Telefone { get => telefone; set => telefone = value; }
        public string DocPessoal { get => docPessoal; set => docPessoal = value; }
        public string DocFiscal { get => docFiscal; set => docFiscal = value; }
    }
}
