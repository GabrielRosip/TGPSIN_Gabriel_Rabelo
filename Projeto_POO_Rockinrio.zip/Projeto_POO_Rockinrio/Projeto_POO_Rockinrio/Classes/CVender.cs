﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projeto_POO_Rockinrio.Classes
{
    class CVender
    {
        private string oidVender;
        private string vender_entidade;
        private string vender_bilhete;
        private DateTime data_de_venda;
        private DateTime data_de_disponivel;

        public DateTime Data_de_disponivel { get => data_de_disponivel; set => data_de_disponivel = value; }
        public DateTime Data_de_venda { get => data_de_venda; set => data_de_venda = value; }
        public string Vender_bilhete { get => vender_bilhete; set => vender_bilhete = value; }
        public string Vender_entidade { get => vender_entidade; set => vender_entidade = value; }
        public string OidVender { get => oidVender; set => oidVender = value; }
    }
}
