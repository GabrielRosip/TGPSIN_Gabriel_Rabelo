﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projeto_POO_Rockinrio.Classes
{
    class CComprar
    {
        private string oidComprar;
        private string compra_pessoa;
        private string compra_bilhete;
        private DateTime compra_data;

        public string OidComprar { get => oidComprar; set => oidComprar = value; }
        public string Compra_pessoa { get => compra_pessoa; set => compra_pessoa = value; }
        public string Compra_bilhete { get => compra_bilhete; set => compra_bilhete = value; }
        public DateTime Compra_data { get => compra_data; set => compra_data = value; }
    }
}
