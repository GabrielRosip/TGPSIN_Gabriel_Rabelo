﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projeto_POO_Rockinrio.Classes
{
    class CEntidade
    {
        private string oidEntidade;
        private string Nome;
        private string NIF;

        public string OidEntidade { get => oidEntidade; set => oidEntidade = value; }
        public string Nome1 { get => Nome; set => Nome = value; }
        public string NIF1 { get => NIF; set => NIF = value; }
    }
}
