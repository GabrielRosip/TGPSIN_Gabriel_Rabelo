﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projeto_POO_Rockinrio.Classes
{
    class CDocumento
    {
        private string oidDocumento;
        private string numero;
        private string TipoDocumento;
        private DateTime data_de_validade;

        public string OidDocumento { get => oidDocumento; set => oidDocumento = value; }
        public string Numero { get => numero; set => numero = value; }
        public string TipoDocumento1 { get => TipoDocumento; set => TipoDocumento = value; }
        public DateTime Data_de_validade { get => data_de_validade; set => data_de_validade = value; }
    }
}
