﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projeto_POO_Rockinrio.Classes
{
    class CUtilizar
    {
        private string utilizar_pessoa;
        private string utilizar_bilhete;
        private DateTime data_de_utilizacao;
        private string oidUtilizar;

    
        public DateTime Data_de_utilizacao { get => data_de_utilizacao; set => data_de_utilizacao = value; }
        public string OidUtilizar { get => oidUtilizar; set => oidUtilizar = value; }
        public string Utilizar_pessoa { get => utilizar_pessoa; set => utilizar_pessoa = value; }
        public string Utilizar_bilhete { get => utilizar_bilhete; set => utilizar_bilhete = value; }
    }
}
