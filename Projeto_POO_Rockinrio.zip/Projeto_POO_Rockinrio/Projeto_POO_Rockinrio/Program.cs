﻿using System;

namespace Projeto_POO_Rockinrio
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
